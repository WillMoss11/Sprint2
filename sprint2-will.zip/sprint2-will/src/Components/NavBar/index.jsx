import Header from "./Header";
import Footer from "./Footer";

function index() {
  return (
    <div>
      <Header />
      <Footer />
    </div>
  );
}

export default index;