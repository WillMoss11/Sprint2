import React from "react";
import OrderPage from "./OrderPage";

function index() {
  return (
    <div>
      <OrderPage />
    </div>
  );
}

export default index;